Yahoo Finance IDX import sample
Retrieved: 2026-11-01
Daily price coverage: 2016-10-31 to 2026-10-30
Symbols: BBCA, BBRI, BMRI, BBNI, BNGA, TLKM, ASII, UNVR, ICBP, INDF; benchmark JKSE (^JKSE).
Drop this ZIP directly onto the Factor Zoo chart. It contains prices.csv, ihsg.csv data in prices.csv via ticker=JKSE, and fundamentals.csv.
Adjusted closes are used for momentum, SMA200, beta, and residual-volatility calculations. TTM dividend yields are derived from Yahoo per-share cash dividend events and raw closes.
See manifest.json for field basis and limitations. Quote-level valuation fields are not historical point-in-time observations. Missing fields are blank, never imputed.
